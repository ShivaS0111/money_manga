package com.invia.money_manga

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
