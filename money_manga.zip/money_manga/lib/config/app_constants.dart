class AppConstants {
  static const page_size = 20;
  static const DB_NAME = "TheNewzapp";
  static const no_items_found = "No items found";
}