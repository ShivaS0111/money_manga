
import 'package:get/get.dart';

class SpendingListController extends GetxController {
  final String title = 'My Awesome View';

  var list = ['1','1'];

}