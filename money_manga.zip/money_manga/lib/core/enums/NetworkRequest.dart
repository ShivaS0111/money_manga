enum NetworkRequest11 {
  POST,
  GET,
  //DELETE,
  //PUT
}