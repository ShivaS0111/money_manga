import 'package:floor/floor.dart';

@dao
abstract class GitDao {

  /*@Query('SELECT * FROM Product WHERE id = :id')
  Future<Product> findProductById( String id);*/

  /*@Query('SELECT * FROM Product')
  Future<List<Product>> findAllProducts();

  @Query('SELECT * FROM Product')
  Stream<List<Product>> findAllProductsAsStream();

  @insert
  Future<void> insertProduct(Product product);

  @insert
  Future<void> insertProducts(List<Product> products);

  @update
  Future<void> updateProduct(Product product);

  @update
  Future<void> updateProducts(List<Product> product);

  @delete
  Future<void> deleteProduct(Product product);

  @delete
  Future<void> deleteProducts(List<Product> products);*/
}
